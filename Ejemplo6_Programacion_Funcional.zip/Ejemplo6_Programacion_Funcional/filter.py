'''
    La funcion filter se aplica sobre una coleccion donde
    filtramos segun el valor devuelto por otra funcion
    la funcion tiene que devolver un valor booleano:
    True -> nos lo quedamos, False -> lo descartamos
    sintaxis:  filter(funcion, coleccion) 
'''

# Ejemplo 1
numeros = [1,2,3,4,5,6,7,8,9]

def soloPares(num):
    if (num % 2 == 0):
        return True   # me lo quedo
    else:
        return False  # lo descarto
    
numerosPares = list(filter(soloPares, numeros))
print(numerosPares)

# Ejemplo 2
alumnos = dict(Juan=6.4, Maria=3.3, Luis=6.4, Adolfo=2.1)

def suspensos(item):
    if item[1] < 5 :
        return True
    else :
        return False
    
alumnosSuspensos = dict(filter(suspensos, alumnos.items()))
print(alumnosSuspensos)


# Ejemplo 3
class Persona:
    def __init__(self, nombre, edad):
        # pass   no hace nada solo hace que la funcion este implementada
        
        # propiedades o atributos publicos
        self.nombre = nombre
        self.edad = edad
        
    def mostrarInfo(self):
        print("Hola, me llamo {} y tengo {} años".format(self.nombre, self.edad))
        
personas = [Persona("Juan", 17), Persona("Maria", 19), Persona("Pedro", 22)]

def mayoresEdad(persona):
    mayor = False
    if persona.edad >= 18 :
        mayor=True
    return mayor

mayores = list(filter(mayoresEdad, personas))
for person in mayores:
    person.mostrarInfo()