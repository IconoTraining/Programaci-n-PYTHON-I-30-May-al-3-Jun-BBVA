''' *********************   Map  ******************* '''
# Ejemplo 1
numeros = [3,8,4,15,30]
numerosDobles = list(map(lambda numero: numero * 2, numeros))
print(numerosDobles)

# Ejemplo 2
alumnos = dict(Juan=6.4, Maria=8.3, Luis=6.4, Adolfo=7.1)
nuevasNotas = dict(map(lambda item: (item[0], item[1]+1), alumnos.items()))
print(nuevasNotas)