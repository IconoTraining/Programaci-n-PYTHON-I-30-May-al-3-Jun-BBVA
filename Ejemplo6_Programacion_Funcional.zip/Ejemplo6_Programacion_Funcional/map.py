'''
    la funcion map se aplica sobre una coleccion donde
    a cada elemento le aplicamos el resultado de otra funcion.
    La funcion tiene que devolver un nuevo elemento o el elemento modificado
    sintaxis:   map(funcion, coleccion)
'''
# Ejemplo 1
def duplicar(numero):
    return numero * 2

numeros = [3,8,4,15,30]
numerosDobles = list(map(duplicar, numeros))
print(numerosDobles)
print(numeros)

# Ejemplo 2
alumnos = dict(Juan=6.4, Maria=8.3, Luis=6.4, Adolfo=7.1)

def subirPunto(item):
    #print(item)
    return item[0], item[1]+1

nuevasNotas = dict(map(subirPunto, alumnos.items()))
print(nuevasNotas)

# Ejemplo 3
class Persona:
    def __init__(self, nombre, edad):
        # pass   no hace nada solo hace que la funcion este implementada
        
        # propiedades o atributos publicos
        self.nombre = nombre
        self.edad = edad
        
    def mostrarInfo(self):
        print("Hola, me llamo {} y tengo {} años".format(self.nombre, self.edad))
        
personas = [Persona("Juan", 17), Persona("Maria", 19), Persona("Pedro", 22)]

def modificarPersonas(persona):
    persona.nombre = persona.nombre.upper()
    persona.edad += 1
    return persona 

personas = list(map(modificarPersonas, personas))

for person in personas:
    person.mostrarInfo()