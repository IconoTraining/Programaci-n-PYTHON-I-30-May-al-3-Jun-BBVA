'''
    La funcion reduce, le pasamos un coleccion 
    y devuelve un solo resultado
    la funcion recibe 2 parametros:
        - el primero actua como acumulador
        - el segundo es el item recibido
    sintaxis: reduce(funcion, coleccion)
    
    IMPORTANTE: hay que importar reduce
'''

# Ejemplo 1 
from functools import reduce


numeros = [1,2,3,4,5,6,7,8,9]

def sumar(resultado, num):
    return resultado + num

print(reduce(sumar, numeros))

# Ejemplo 2
colores = ['rojo','verde','azul']

def concatenar(resultado, color):
    return resultado.upper() + "-" + color.upper()

cadenaColores = reduce(concatenar, colores)
print(cadenaColores)