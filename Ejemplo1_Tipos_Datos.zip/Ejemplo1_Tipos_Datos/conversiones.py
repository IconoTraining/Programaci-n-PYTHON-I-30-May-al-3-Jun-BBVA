import math

# convertir texto a numero entero
dato = input("Introduce un numero: ")
print(type(dato))
numero1 = int(dato)
print(type(numero1))

# convertir texto a numero decimal
radio = float(input("Introduce el radio del circulo: "))
print("Area del ciculo", math.pi * radio**2)
print("Area del ciculo", round(math.pi * radio**2, 2)) #round(que, num_decimales)

# convertir a texto
texto = str(numero1)
print(type(texto))
otro_texto = str(False)
print(type(otro_texto))