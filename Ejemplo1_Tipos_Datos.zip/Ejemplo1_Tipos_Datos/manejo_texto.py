texto = "bienvenidos al curso de Python"
print(texto)

print("capitalize", texto.capitalize())
print("swapcase", texto.swapcase())
print("upper", texto.upper())
print("lower", texto.lower())

print("iasalnum", texto.isalnum())
print("isalpha", "Pepito".isalpha())
print("isdigit", "246".isdigit())

print("islower", texto.islower())
print("isupper", texto.isupper())

ejemplo = "     lunes      "
print(ejemplo, end=".\n")
print(ejemplo.lstrip(), end=".\n")
print(ejemplo.rstrip(), end=".\n")
print(ejemplo.strip(), end=".\n")

print("Longitud:", texto.__len__())
print("Longitud:", len(texto))

print("replace:", texto.replace('e','E'))

print("split:", texto.split())
datos = "30/5/2022".split("/")
print("Dia:", datos[0])
print("Mes:", datos[1])
print("Año:", datos[2])

datosPersonales = "Anabel Vegas Careces".split()
print("Nombre:", datosPersonales[0])
print("Apellido 1:", datosPersonales[1])
print("Apellido 2:", datosPersonales[2])

print("Max: ", max(texto))
print("Min: ", min(texto))