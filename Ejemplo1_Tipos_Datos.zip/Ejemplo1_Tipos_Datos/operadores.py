# Operadores aritmeticos (+, -, *, /, %, **, //)
numero1 = 7
numero2 = 3
print("Suma:", numero1 + numero2)
print("Resta:", numero1 - numero2)
print("Multiplicacion:", numero1 * numero2)
print("Division:", numero1 / numero2)
print("Division entera:", numero1 // numero2)
print("Resto:", numero1 % numero2)
print("Potencia:", numero1 ** numero2)

# Operadores de asignacion (+=, -=, *=, /=, %=, **=, //=)
numero1 += 2     # numero1 = numero1 + 2  
# numero1++   EN Python NO EXISTEN incrementos, ni decrementos 

# Operadores de comparacion (>, <, >=, <=, ==, !=)
print(numero1 < numero2)

# Operadores logicos (and, or, not)
print(numero1 < 10 and numero2 < 5)
print(numero1 < 10 or numero2 > 5)
print(numero2 > 5)
print(not numero2 > 5)

# Operadores de identidad(is, is not)
num1 = 6
num2 = 6
print("Iguales?", num1 == num2)
print("Mismo contenido?", num1 is num2)

nombres1 = ["Luis", "Juan"]
nombres2 = ["Luis", "Juan"]
print("Iguales?", nombres1 == nombres2)  # True
print("Mismo contenido?", nombres1 is nombres2) # False
nombres3 = nombres2
print("Mismo contenido?", nombres3 is nombres2)

nombres4 = []
nombres4 += nombres2
print(nombres4)

# Operadores de pertenencia(in, not in)
print("Luis" in nombres1)
print("Maria" not in nombres2)