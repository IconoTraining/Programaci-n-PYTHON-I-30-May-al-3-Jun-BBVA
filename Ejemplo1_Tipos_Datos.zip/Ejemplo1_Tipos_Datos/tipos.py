'''
    En este ejemplo veremos los tipos de datos:
        - Enteros
        - Reales
        - Textos
        - Booleanos
'''

# numeros enteros
numero1 = 5
numero2 = 3
suma = numero1 + numero2
print("Suma:",suma)
print("Suma:" + str(suma)) # solo se pueden concatenar strings
print(type(suma))

# numeros reales
base = 5.78
altura = 9.23
triangulo = base * altura / 2
print("Area del triangulo: ", triangulo)
print(type(triangulo))

# cadenas de texto
nombre = "Pepito"
apellido = 'Perez'
print(nombre, apellido)
print(nombre + " " + apellido)
print(type(nombre))

#booleanos: True o False
soltero = True
print("Estas soltero? ", soltero)
print(type(soltero))