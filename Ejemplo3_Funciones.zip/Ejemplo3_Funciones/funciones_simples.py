# declaracion de funciones

def saludar(nombre):
    print("Bienvenido", nombre, "al curso de Python")
    
def despedir():
    return "Hasta luego"
    

# invocar funciones
saludar("Pepito")

mensaje = despedir()
print(mensaje)

print(despedir())