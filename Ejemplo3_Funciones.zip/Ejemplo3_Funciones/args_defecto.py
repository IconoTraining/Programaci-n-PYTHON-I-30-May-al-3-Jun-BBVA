def datosTrabajador(nombre, sueldo=21000, estadoCivil="Soltero") :
    return nombre + " su sueldo es " + str(sueldo) + " y esta " + estadoCivil

# Formas de invocar a la funcion
print(datosTrabajador("Juan"))
print(datosTrabajador("Maria", 35000))
print(datosTrabajador("Pedro", 28000, "Casado"))

# El estado civil de Laura lo interpreta como sueldo
print(datosTrabajador("Laura", "Separada"))

# Asi no hay problema
print(datosTrabajador("Laura", estadoCivil="Separada"))


def concatenar(*datos, separador=" | ") :
    return separador.join(datos)

print(concatenar('lunes','martes','miercoles','jueves','viernes'))
print(concatenar('lunes','martes','miercoles','jueves','viernes', separador="-"))