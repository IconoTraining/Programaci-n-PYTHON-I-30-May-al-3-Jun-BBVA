def procesarTexto(texto):
    return texto.upper(), texto.lower(), len(texto)

# recuperamos con multiples variables
txtMay, txtMin, txtLen = procesarTexto("Hola, que tal?")
print(txtMay)
print(txtMin)
print(txtLen)

# recuperamos con una lista
lista = procesarTexto("Hola, que tal?")
for dato in lista:   #forEach
    print(dato)
    
for i in range(len(lista)):  # for tradicional
    print(lista[i])