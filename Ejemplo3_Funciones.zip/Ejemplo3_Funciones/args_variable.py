def sumar(*numeros):
    suma = 0
    for num in numeros :
        suma += num
    return suma

print(sumar())
print(sumar(6))
print(sumar(6,3))
print(sumar(6,3,5,7,2,8))


def procesarNotas(nombre, *notas):
    media = sumar(*notas) / len(notas)
    return nombre.upper(), media

nombreAlumno, notaMedia = procesarNotas("Juan", 4,9,6,1)
print(nombreAlumno,": con nota media:", round(notaMedia,1))

nombreAlumno, notaMedia = procesarNotas("Maria", 8,5,7)
print(nombreAlumno,": con nota media:", round(notaMedia,1))

nombreAlumno, notaMedia = procesarNotas("Jorge", 5,6)
print(nombreAlumno,": con nota media:", round(notaMedia,1))

nombreAlumno, notaMedia = procesarNotas("Laura", 8,9,7,9,8,10)
print(nombreAlumno,": con nota media:", round(notaMedia,1))