'''
    tuplas: colecciones ordenadas pero inmutables
    si permite duplicados
    se crean ()
    Ejemplos de uso: dias de la semana, meses del año, estado civil, puntos cardinales
'''

dias = ('lunes','martes','miercoles','jueves','viernes','sabado','domingo')
print(type(dias))   # tuple

print(dias)

# Recorrer una tupla
for dia in dias:
    print(dia)

# Ordena ascendente pero devuelve una lista
print(sorted(dias))
    
# Mostrar el miercoles
print(dias[2])

# En que posicion esta el viernes
print(dias.index('viernes'))

# Cuantos sabados hay en la tupla
print(dias.count('sabado'))

# longitud
print(len(dias))
print(dias.__len__())

''' cosas que no puedo hacer '''
# TypeError: 'tuple' object doesn't support item deletion
# del dias[0]

# TypeError: can only concatenate tuple (not "str") to tuple
# dias = dias + ('otro_domingo')

# Puedo agregar elementos a la tupla siempre que no sean de tipo str
dias = dias + (1,2,3,4,5)
print(dias)

# mostrar el ultimo elemento
print(dias[-1])

# TypeError: '<' not supported between instances of 'int' and 'str'
# print(sorted(dias))