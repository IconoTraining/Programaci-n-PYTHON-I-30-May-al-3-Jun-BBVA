'''
    diccionarios: los elementos se forman par key:value
    las claves no se pueden repetir pero los value si
    si repetimos una clave el valor se sobreescribe
    se crean con {}
'''

alumnos = {"Juan":6.4, "Maria":8.3, "Luis":6.4,"Adolfo":7.1, "Maria":9.3}
print(type(alumnos))  # dict

print(alumnos)

# mostrar todas las claves -> nombres de los alumnos
print(alumnos.keys())

# mostrar los values -> notas de los alumnos
print(alumnos.values())

# ordena pero solo devuelve una lista con los nombres
print(sorted(alumnos))

lista = sorted(alumnos)
alumnos_ordenado = dict()
for alum in lista:
    alumnos_ordenado[alum] = alumnos[alum]
print(alumnos_ordenado)

# Ordena por clave y devuelve un diccionario
print(dict(sorted(alumnos.items())))

# Agregar un nuevo alumno
alumnos['Pedro'] = 4.7
print(alumnos)

# Ver la nota de Pedro
print(alumnos['Pedro'])

# Eliminar a Adolfo
del alumnos['Adolfo']
print(alumnos)

# Recorrer un diccionario
for alum in alumnos:
    print(alum)    # solo muestra las keys
    
for clave, valor in alumnos.items():
    print(clave,valor)
    
for item in alumnos.items():
    print(item)    # nos devuelve una tupla por cada par
 
# otras formas de crear diccionarios
otro = dict([("Juan",6.4), ("Maria",8.3), ("Luis",6.4),("Adolfo",7.1), ("Maria",9.3)]) 

# OJO!!! que aqui si hay claves duplicadas da error   
#otroMas = dict(Juan=6.4, Maria=8.3, Luis=6.4, Adolfo=7.1, Maria=9.3)
otroMas = dict(Juan=6.4, Maria=8.3, Luis=6.4, Adolfo=7.1)

print(otro)
print(otroMas)