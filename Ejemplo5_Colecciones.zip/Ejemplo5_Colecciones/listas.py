# Todas las colecciones soportan elementos de diferentes tipos
'''
    listas: colecciones ordenadas de objetos
    Si permite elementos duplicados
    se crean con []
'''

colores = ['rojo','verde','azul']
print(type(colores))  # list

# mostrar la lista
print(colores)

# ordenar la lista pero no aplica cambios, solo lo muestra
print(sorted(colores))

# ordenar la lista descendente
print(list(reversed(sorted(colores))))

# IMPORTANTE, la lista si queremos modificarla
#colores = sorted(colores)

# mostrar el color verde
print(colores[1])

# borrar el color azul -> borrar por indice
del colores[2]

# añadir el color amarillo
colores = colores + ['amarillo ']
print(colores)

# concatenar listas
masColores = ['blanco','negro','rosa','azul']
nuevaLista = colores + masColores
print(nuevaLista)

# borrar el color rosa -> borrar por elemento
nuevaLista.remove("rosa")
print(nuevaLista)

# otra forma de borrar por indice. Eliminar el color azul
nuevaLista.__delitem__(5)
print(nuevaLista)

# añadir un elemento al final
nuevaLista.append('naranja')
print(nuevaLista)

# insertar nuevo elemento en una determinada posicion
nuevaLista.insert(0, 'marron')
print(nuevaLista)

# contar cuantos elementos 'verde' tengo en mi lista
print(nuevaLista.count('verde'))

# mostrar el indice donde esta el color verde
print(nuevaLista.index('verde'))

# longitud de la lista
print(len(nuevaLista))
print(nuevaLista.__len__())

# mostrar el ultimo elemento de la lista
print(nuevaLista[len(nuevaLista) - 1])
print(nuevaLista[-1])

# mostrar el tercer elemento empezando por el final
print(nuevaLista[-3])

# mostrar los 3 ultimos elementos
print(nuevaLista[-3:])

# mostrar todos los elementos
print(nuevaLista[:])

# mostrar los elementos del indice 2 y 3 (El 4 queda excluido)
print(nuevaLista[2:4])

# mostrar desde -4 hasta -2
print(nuevaLista[-4:-2])

# No funciona, devuelve la lista vacia
print(nuevaLista[-2:-4])

# borrar todos los elementos de la lista
nuevaLista.clear()
