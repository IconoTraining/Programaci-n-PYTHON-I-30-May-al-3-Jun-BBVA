'''
    conjuntos: colecciones no ordenadas, no existe un indice
    no se garantiza el orden de entrada
    no permite elementos duplicados, los ignora
    se crean con {}
'''

frutas = {'manzana','naranja','pera','naranja','platano'}
print(type(frutas)) # set

print(frutas)

# comprobar si tengo fresas
print('fresas' in frutas)

# comprobar si tengo pera
print('pera' in frutas)

# agregamos fresas al conjunto
frutas.add("fresas")
print(frutas)

# eliminar platano
frutas.remove('platano')
print(frutas)

# mostrar la longitud
print(len(frutas))
print(frutas.__len__())

# ordenar 
print(sorted(frutas))
lista = sorted(frutas)

numeros1 = {1,2,3,4,5,6,7,8,9}
numeros2 = {0,2,4,6,8,10}

# interseccion de conjuntos: elementos comunes
print(numeros1.intersection(numeros2))
print(numeros1 & numeros2)

# mostrar los elementos de numeros1 que no estan en numeros2
print(numeros1.difference(numeros2))
print(numeros1 - numeros2)

# lo mismo pero del reves
print(numeros2.difference(numeros1))
print(numeros2 - numeros1)

# los elementos de ambos conjuntos que estan fuera de la interseccion
print(numeros1.symmetric_difference(numeros2))
print(numeros2 ^ numeros1)

# borrar los elementos de numeros1 que esten en numeros2
numeros1.difference_update(numeros2)
print(numeros1)

''' compresion de colecciones   '''
def filtrar():
    y = set()   # crear un conjunto vacio
    for letra in 'abracadabra' :
        if letra not in 'abc':
            y.add(letra)
    return y

x = filtrar()
print(x)

x = {letra  for letra in 'abracadabra' if letra not in 'abc' }
print(x)