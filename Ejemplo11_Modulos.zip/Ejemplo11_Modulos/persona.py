class Persona:
    def __init__(self, nombre, edad):
        # pass   no hace nada solo hace que la funcion este implementada
        
        # propiedades o atributos publicos
        self.nombre = nombre
        self.edad = edad
        
    def mostrarInfo(self):
        print("Hola, me llamo {} y tengo {} años".format(self.nombre, self.edad))