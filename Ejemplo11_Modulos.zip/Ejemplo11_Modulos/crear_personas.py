# Opcion 1
'''
import persona

p1 = persona.Persona("Juan", 27)
p1.mostrarInfo()
'''

# Opcion 2
'''
from persona import Persona

p1 = Persona("Juan", 27)
p1.mostrarInfo()
'''

# Opcion 3
from persona import Persona as person

p1 = person("Juan", 27)
p1.mostrarInfo()
