'''
    CRUD: Create, Read, Update, Delete
'''

# importamos sqlite3
from itertools import product
import sqlite3

# Abrir una conexion a la BBDD
conexion = sqlite3.connect("tienda.db")

# Obtener un cursor
cursor = conexion.cursor()

''' *****************  Insertamos datos  ***************** '''
'''
cursor.execute("INSERT INTO PRODUCTOS VALUES (1, 'Pantalla', 89.95)")

lista = [ (2, 'Teclado', 29.50), (3, 'Raton', 15.0), (4, 'Impresora', 120.80) ]
sql = "INSERT INTO PRODUCTOS VALUES (?, ?, ?)"
cursor.executemany(sql, lista)
conexion.commit()
'''

''' ****************   Consultar todos los productos ****************  '''
cursor.execute("select * from PRODUCTOS")

# recoger los resultados obtenidos
productos = cursor.fetchall()
for prod in productos :
    print(prod)
print(" -------- FIN ------- ")

''' ****************   Consultar productos con precio inferior a los 50€ ****************  '''
cursor.execute("select * from PRODUCTOS where PRECIO < 50")

# recoger los resultados obtenidos
productos = cursor.fetchall()
for prod in productos :
    print(prod)
print(" -------- FIN ------- ")


''' ***************   Modificar el precio de la impresora ******************* '''
cursor.execute('UPDATE PRODUCTOS SET precio = 110 where descripcion = "Impresora" ')
conexion.commit()


''' ***************   Eliminar el raton de la tabla ******************** '''
cursor.execute('DELETE FROM PRODUCTOS where codigo = 3')
conexion.commit()

conexion.close()
