'''
    En este archivo gemeramos la estructura de la BBDD
'''
# importamos sqlite3
import sqlite3

# Abrir una conexion a la BBDD
# si no existe la crea en ese momento
conexion = sqlite3.connect("tienda.db")

# Obtener un cursor
cursor = conexion.cursor()

# Crear la tabla
sql = "CREATE TABLE PRODUCTOS (codigo INTEGER PRIMARY KEY, descripcion TEXT, precio REAL)"
cursor.execute(sql)

# Importante hacer el commit
conexion.commit()

# cerrar la conexion
conexion.close()