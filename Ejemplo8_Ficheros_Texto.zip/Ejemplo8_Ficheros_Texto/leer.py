# ruta absoluta
#fichero = open("/Users/anaisabelvegascaceres/Desktop/Python_BBVA_30_Mayo/Ejemplo8_Ficheros_Texto/fichero.txt", "rt", encoding="utf-8")

# ruta relativa
fichero = open("Ejemplo8_Ficheros_Texto/fichero.txt", "rt", encoding="utf-8")

# leer todo el contenido
texto = fichero.read()
print(type(texto))
print(texto)
print("----- FIN -----")

# leer la primera linea
fichero.seek(0)   # muevo el puntero al primer caracter
linea = fichero.readline()
print(linea)
print("----- FIN -----")

# leer todas las lineas
fichero.seek(0)
lineas = fichero.readlines()
for linea in lineas:
    print(linea, end="")
print("\n----- FIN -----")

# leer todas las lineas
fichero.seek(0)
lineas = list(fichero)
for linea in lineas:
    print(linea, end="")
print("\n----- FIN -----")

# cerrar el fichero
fichero.close()