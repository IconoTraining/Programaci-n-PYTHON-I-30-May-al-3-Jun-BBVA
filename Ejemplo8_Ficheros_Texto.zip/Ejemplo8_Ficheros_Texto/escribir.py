# si quiero abrir el fichero en modo lectura y escritura
# a+ -> a append y el + permite lectura y escritura
#fichero = open("Ejemplo8_Ficheros_Texto/fichero_escritura.txt", "a+", encoding="utf-8")

fichero = open("Ejemplo8_Ficheros_Texto/fichero_escritura.txt", "wt", encoding="utf-8")

texto = "Esto es un ejemplo"
fichero.write(texto)

fichero.close()