'''
    leer el contenido de fichero.txt
    escribirlo en fichero_copia.txt
    leer fichero_copia.txt y mostrar el resultado
'''
# Abrir el fichero de lectura
ficheroLectura = open("Ejemplo8_Ficheros_Texto/fichero.txt", "rt", encoding="utf-8")

# Abrir el fichero de escritura
ficheroEscritura = open("Ejemplo8_Ficheros_Texto/fichero_copia.txt", "a+", encoding="utf-8")

# leer todo el contenido como una lista
contenido = list(ficheroLectura)

# Recorro la lista y cada linea la copio en el otro fichero
for linea in contenido :
    ficheroEscritura.write(linea)
    
# mostramos el resultado
ficheroEscritura.seek(0)  # posicionamos el puntero en el primer caracter
for linea in ficheroEscritura.readlines() :
    print(linea, end="")
print()
    
# cerramos ficheros
ficheroLectura.close()
ficheroEscritura.close()