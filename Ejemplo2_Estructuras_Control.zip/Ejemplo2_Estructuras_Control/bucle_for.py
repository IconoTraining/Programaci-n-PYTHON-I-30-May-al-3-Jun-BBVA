nombres = ["Luis","Jorge","Maria","Laura","Pedro"]

# Recorrer la coleccion
for nombre in nombres:
    print(nombre)
    
''' ************** rangos ********** '''
# Mostrar los numeros del 0 al 9
for numero in range(10):  # el numero 10 queda excluido
    print(numero)
print(" ------- FIN ------- ")

# Mostrar los numeros del 1 al 10
for numero in range(1, 11):  # el numero 11 queda excluido
    print(numero)
print(" ------- FIN ------- ")

# Mostrar los numeros del 0 al 10 de 2 en 2
for numero in range(0, 11, 2):  # el numero 11 queda excluido
    print(numero)
print(" ------- FIN ------- ")

# Mostrar los numeros del 10 al 1
for numero in range(10, 0, -1):  # el numero 0 queda excluido
    print(numero)
print(" ------- FIN ------- ")

# Mostrar los numeros del -10 al -100 de 10 en 10
for numero in range(-10, -101, -10):  # el numero -101 queda excluido
    print(numero)
print(" ------- FIN ------- ")

# Recorrer la coleccion a través del indice
for i in range(len(nombres)):  
    print(nombres[i])
print(" ------- FIN ------- ")