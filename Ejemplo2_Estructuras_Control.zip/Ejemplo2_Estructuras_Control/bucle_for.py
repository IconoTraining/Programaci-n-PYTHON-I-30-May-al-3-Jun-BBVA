nombres = ["Luis","Jorge","Maria","Laura","Pedro"]

# Recorrer la coleccion
for nombre in nombres:
    print(nombre)
    
''' ************** rangos ********** '''
# Mostrar los numeros del 0 al 9
for numero in range(10):  # el numero 10 queda excluido
    print(numero)
print(" ------- FIN ------- ")