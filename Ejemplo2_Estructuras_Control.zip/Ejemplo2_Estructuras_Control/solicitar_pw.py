from sqlite3 import Cursor


# Solicitar pw al usuario hasta que acierte que es curso
# solo tiene 3 intentos

intento = 1
while intento <= 3 :
    pw = input("Introduce pw: ")
    if "curso" == pw :
        print("Correcto")
        break
    else :
        print("Pw incorrecto. Te quedan", 3-intento, "intentos")
    intento += 1