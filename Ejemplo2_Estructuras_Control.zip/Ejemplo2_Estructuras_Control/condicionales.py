# solicitar al usuario un numero entre 1 y 10
#  Si es menor que 1 mostrar un mensaje
#  Si es mayor que 10 otro mensaje
#  Si esta entre 1 y 10 mensaje "Correcto"

numero = int(input("Introduce un numero del 1 y 10: "))

if numero < 1 :
    print("El numero debe ser mayor o igual a 1")
elif numero > 10 :
    print("El numero no puede ser mayor que 10")
else :
    print("Correcto")