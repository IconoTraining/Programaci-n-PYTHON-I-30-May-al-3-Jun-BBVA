# solicitar una letra (l,m,x,j,v,s,d) y decir a que dia de la semana pertenece
# El usuario lo puede escribir minuscula y mayuscula
# probar: lower(), upper(), ==, is, or

letra = input("Introduce letra del dia de la semana: ")

if letra == 'l' or letra == 'L':
    print("Es lunes")
elif letra.lower() == 'm':
    print("Es martes")
elif letra.upper() == 'X':
    print("Es miercoles")
elif letra is "j" or letra is "J":
    print("Es jueves")
elif letra.lower() == 'v':
    print("Es viernes")
elif letra is "s" or letra is "S":
    print("Es sabado")
elif letra is "d" or letra is "D":
    print("Es domingo")
else :
    print("Dia desconocido")