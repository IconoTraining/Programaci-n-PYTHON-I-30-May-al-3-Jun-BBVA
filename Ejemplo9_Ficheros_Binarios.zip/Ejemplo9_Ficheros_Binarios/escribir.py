import pickle

colores = ['rojo','verde','azul']
fichero = open("Ejemplo9_Ficheros_Binarios/binario.pckl", "wb")
pickle.dump(colores, fichero)
fichero.close()