import pickle

fichero = open("Ejemplo9_Ficheros_Binarios/binario.pckl", "rb")

colores = pickle.load(fichero)
print(colores)
print(type(colores))

fichero.close()