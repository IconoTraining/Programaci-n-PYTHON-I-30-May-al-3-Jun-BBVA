# try-except-else-finally

try:
    # ValueError
    # invalid literal for int() with base 10: 'ocho'
    numero1 = int(input("Introduce dividendo: "))
    numero2 = int(input("Introduce divisor:"))
    
    # TypeError
    # can only concatenate str (not "int") to str
    #print("Dividendo: " + numero1)
    
    # ZeroDivisonError
    # division by zero
    division = numero1 / numero2
except (ZeroDivisionError, TypeError, ValueError) as error:
    print("Ha ocurrido un error")
    print(type(error))
    print(error)
except Exception as ex:
    print("Ha ocurrido un error")
    print(type(ex))
    print(ex)
else:
    # si no hay error muestra el resultado
    print(division)
finally:
    print("*********** FIN *********")
    
    
# Otros ejemplos de error

# IndexError: list index out of range
colores = ['rojo','verde','azul']
print(colores[6])