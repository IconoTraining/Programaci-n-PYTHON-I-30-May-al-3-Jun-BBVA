"""
   Una clase encapsulada tiene sus propiedades privadas y 
   se accede a ellas a través de los metodos get y set publicos 
"""
class Fecha:
    def __init__(self, dia, mes, anyo):
        self.setDia(dia)
        self.setMes(mes)
        self.seyAnyo(anyo)

    def getDia(self):
        return self.__dia
    
    def setDia(self, dia):
        if dia >=1 and dia <=30 :
            self.__dia = dia
        else:
            self.__dia=0
            print("Dia no valido")
            
    def getMes(self):
        return self.__mes
    
    def setMes(self, mes):
        if mes >=1 and mes <=12 :
            self.__mes = mes
        else:
            self.__mes=0
            print("Mes no valido")
            
    def getAnyo(self):
        return self.__anyo
    
    def seyAnyo(self, anyo):
        if anyo == 2022 or anyo == 2023 :
            self.__anyo = anyo
        else:
            self.__anyo=0
            print("Anyo no valido")

    def mostrar(self):
        print(self.getDia(), self.getMes(), self.getAnyo(), sep="/")
         
hoy = Fecha(30,5,2022)    
hoy.mostrar()

otra = Fecha(-678, 899, 942)
otra.mostrar()