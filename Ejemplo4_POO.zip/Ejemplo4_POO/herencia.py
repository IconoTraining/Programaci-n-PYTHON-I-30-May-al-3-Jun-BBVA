class Vehiculo:
    
    def __init__(self,motor, velocidad) -> None:
        self.__motor = motor  # booleana
        self.__velocidad = velocidad
        
    def isMotor(self):
        return self.__motor
    
    def getVelocidad(self):
        return self.__velocidad
    
    def arrancar(self):
        print("Arrancando el vehiculo")
        
    def parar(self):
        print("Parando el vehiculo")
        
        
class Coche(Vehiculo):
    
    def __init__(self, motor, velocidad, plazas, combustible) -> None:
        super().__init__(motor, velocidad) # invoca al constructor de la superclase
        self.__plazas = plazas
        self.__combustible = combustible
        
    def getPlazas(self):
        return self.__plazas
    
    def getCombustible(self):
        return self.__combustible
    
    def repostar(self):
        print("Repostando combustible")
        

# Crear un coche
coche = Coche(True, 200, 5, "Gasolina")
coche.repostar()
coche.arrancar()
coche.parar()
print("Plazas:", coche.getPlazas())
print("Velocidad maxima:", coche.getVelocidad())
print("Combustible:", coche.getCombustible())