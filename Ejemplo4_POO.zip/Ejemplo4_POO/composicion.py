class Direccion:
    def __init__(self, calle, numero, poblacion):
        self.calle = calle
        self.numero = numero
        self.poblacion = poblacion
        
    def mostrar(self):
        # Alcala,36 Madrid
        return self.calle + "," + str(self.numero) + " " + self.poblacion


class Persona:
    def __init__(self, nombre, edad, direccion):
        self.nombre = nombre
        self.edad = edad
        self.direccion = direccion
        
    def mostrarInfo(self):
        print("Hola, me llamo {}, tengo {} años y vivo en {}"
              .format(self.nombre, self.edad, self.direccion.mostrar()))
        
        
# crear objetos o instancias de Persona
dir = Direccion("Alcala", 36, "Madrid")
juan = Persona("Juan", 27, dir)
maria = Persona("Maria", 38, Direccion("Mayor",57,"Sevilla"))

juan.mostrarInfo()
maria.mostrarInfo()

# Como son propiedades publicas tengo acceso
juan.direccion = Direccion("Castellana", 182, "Madrid")
juan.mostrarInfo()

