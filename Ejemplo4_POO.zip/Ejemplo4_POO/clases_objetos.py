# Crear una clase Persona con constructor o inicializador
class Persona:
    def __init__(self, nombre, edad):
        # pass   no hace nada solo hace que la funcion este implementada
        
        # propiedades o atributos publicos
        self.nombre = nombre
        self.edad = edad
        
    def mostrarInfo(self):
        print("Hola, me llamo", self.nombre, "y tengo", self.edad, "años")
        print("Hola, me llamo {} y tengo {} años".format(self.nombre, self.edad))
        
        
# crear objetos o instancias de Persona
juan = Persona("Juan", 27)
maria = Persona("Maria", 38)

juan.mostrarInfo()
maria.mostrarInfo()

# Como son propiedades publicas tengo acceso
juan.edad += 1
juan.mostrarInfo()

